const winston = require("winston");
module.exports = winston.createLogger({
  level: "info",
  format: winston.format.combine(winston.format.timestamp(), winston.format.simple()),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: "nexus.log", maxsize: 5*1024*1024 }),
  ],
});
