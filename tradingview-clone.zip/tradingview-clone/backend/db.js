// db.js — SQLite database layer
const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "nexus.db"));

// WAL mode for performance
db.pragma("journal_mode = WAL");
db.pragma("synchronous = NORMAL");
db.pragma("cache_size = 10000");

// ── Schema ───────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS ticks (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol    TEXT NOT NULL,
    price     REAL NOT NULL,
    volume    REAL DEFAULT 0,
    ts        INTEGER DEFAULT (strftime('%s','now'))
  );
  CREATE INDEX IF NOT EXISTS idx_ticks_sym_ts ON ticks(symbol, ts);

  CREATE TABLE IF NOT EXISTS candles (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol    TEXT NOT NULL,
    tf        TEXT NOT NULL,
    time      INTEGER NOT NULL,
    open      REAL, high REAL, low REAL, close REAL, volume REAL,
    UNIQUE(symbol, tf, time)
  );
  CREATE INDEX IF NOT EXISTS idx_candles ON candles(symbol, tf, time);

  CREATE TABLE IF NOT EXISTS ai_analysis (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol    TEXT NOT NULL,
    signal    TEXT,
    confidence INTEGER,
    entry     REAL, sl REAL, tp REAL,
    buys      INTEGER, sells INTEGER, holds INTEGER,
    drawings  TEXT,
    created_at INTEGER DEFAULT (strftime('%s','now'))
  );

  CREATE TABLE IF NOT EXISTS drawings (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   TEXT NOT NULL,
    symbol    TEXT NOT NULL,
    tf        TEXT NOT NULL,
    data      TEXT NOT NULL,
    updated_at INTEGER DEFAULT (strftime('%s','now'))
  );
  CREATE UNIQUE INDEX IF NOT EXISTS idx_drawings ON drawings(user_id, symbol, tf);

  CREATE TABLE IF NOT EXISTS alerts (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   TEXT DEFAULT 'demo',
    symbol    TEXT NOT NULL,
    price     REAL NOT NULL,
    direction TEXT NOT NULL,
    label     TEXT,
    active    INTEGER DEFAULT 1,
    triggered INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (strftime('%s','now'))
  );

  CREATE TABLE IF NOT EXISTS watchlist (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   TEXT NOT NULL,
    symbols   TEXT NOT NULL,
    updated_at INTEGER DEFAULT (strftime('%s','now'))
  );
  CREATE UNIQUE INDEX IF NOT EXISTS idx_watchlist ON watchlist(user_id);
`);

// ── Prepared statements ──────────────────────────────────
const stmts = {
  insertTick:    db.prepare("INSERT INTO ticks(symbol,price,volume) VALUES(?,?,?)"),
  insertCandle:  db.prepare("INSERT OR REPLACE INTO candles(symbol,tf,time,open,high,low,close,volume) VALUES(?,?,?,?,?,?,?,?)"),
  getCandles:    db.prepare("SELECT time,open,high,low,close,volume FROM candles WHERE symbol=? AND tf=? ORDER BY time DESC LIMIT ?"),
  saveAnalysis:  db.prepare("INSERT INTO ai_analysis(symbol,signal,confidence,entry,sl,tp,buys,sells,holds,drawings) VALUES(?,?,?,?,?,?,?,?,?,?)"),
  getAnalysis:   db.prepare("SELECT * FROM ai_analysis WHERE symbol=? ORDER BY created_at DESC LIMIT ?"),
  saveDrawings:  db.prepare("INSERT OR REPLACE INTO drawings(user_id,symbol,tf,data,updated_at) VALUES(?,?,?,?,strftime('%s','now'))"),
  getDrawings:   db.prepare("SELECT data FROM drawings WHERE user_id=? AND symbol=? AND tf=?"),
  createAlert:   db.prepare("INSERT INTO alerts(user_id,symbol,price,direction,label) VALUES(?,?,?,?,?)"),
  getAlerts:     db.prepare("SELECT * FROM alerts WHERE user_id=? AND active=1 ORDER BY created_at DESC"),
  getActiveAlerts: db.prepare("SELECT * FROM alerts WHERE active=1 AND triggered=0"),
  triggerAlert:  db.prepare("UPDATE alerts SET triggered=1 WHERE id=?"),
  getWatchlist:  db.prepare("SELECT symbols FROM watchlist WHERE user_id=?"),
  setWatchlist:  db.prepare("INSERT OR REPLACE INTO watchlist(user_id,symbols,updated_at) VALUES(?,?,strftime('%s','now'))"),
};

module.exports = {
  insertTick: (sym, price, vol) => {
    try { stmts.insertTick.run(sym, price, vol); } catch {}
  },
  insertCandle: (sym, tf, c) => {
    try { stmts.insertCandle.run(sym, tf, c.time, c.open, c.high, c.low, c.close, c.volume); } catch {}
  },
  getCandles: (sym, tf, limit) => {
    const rows = stmts.getCandles.all(sym, tf, limit);
    return rows.reverse().map(r => ({ time:r.time, open:r.open, high:r.high, low:r.low, close:r.close, volume:r.volume }));
  },
  saveAnalysis: (sym, cons) => {
    try { stmts.saveAnalysis.run(sym, cons.sig, cons.conf, cons.entry, cons.sl, cons.tp, cons.buys, cons.sells, cons.holds, JSON.stringify(cons.drawings)); } catch {}
  },
  getAnalysisHistory: (sym, limit) => {
    return stmts.getAnalysis.all(sym, limit).map(r => ({ ...r, drawings: JSON.parse(r.drawings || "[]") }));
  },
  saveDrawings: (uid, sym, tf, data) => {
    try { stmts.saveDrawings.run(uid, sym, tf, JSON.stringify(data)); } catch {}
  },
  getDrawings: (uid, sym, tf) => {
    const row = stmts.getDrawings.get(uid, sym, tf);
    return row ? JSON.parse(row.data) : [];
  },
  createAlert: (body) => {
    const { userId="demo", symbol, price, direction, label="" } = body;
    const r = stmts.createAlert.run(userId, symbol, price, direction, label);
    return { id: r.lastInsertRowid, symbol, price, direction, label };
  },
  getAlerts: (uid) => stmts.getAlerts.all(uid),
  getActiveAlerts: () => stmts.getActiveAlerts.all(),
  triggerAlert: (id) => stmts.triggerAlert.run(id),
  getWatchlist: (uid) => {
    const row = stmts.getWatchlist.get(uid);
    return row ? JSON.parse(row.symbols) : [];
  },
  updateWatchlist: (uid, syms) => {
    stmts.setWatchlist.run(uid, JSON.stringify(syms));
  },
};
