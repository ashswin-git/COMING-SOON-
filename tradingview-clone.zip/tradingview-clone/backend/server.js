// ═══════════════════════════════════════════════════════
//  NEXUS TRADING — Backend Server
//  Express + WebSocket + SQLite + AI Integration
// ═══════════════════════════════════════════════════════
require("dotenv").config();
const express   = require("express");
const http      = require("http");
const WebSocket = require("ws");
const cors      = require("cors");
const helmet    = require("helmet");
const rateLimit = require("express-rate-limit");
const cron      = require("node-cron");
const axios     = require("axios");
const db        = require("./db");
const logger    = require("./logger");

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });

// ── Middleware ───────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.FRONTEND_URL || "http://localhost:3000" }));
app.use(express.json({ limit: "10mb" }));
app.use(rateLimit({ windowMs: 60000, max: 200 }));

// ── WebSocket clients ────────────────────────────────────
const clients = new Map(); // clientId → { ws, subscriptions: Set }

function broadcast(symbol, data) {
  clients.forEach(({ ws, subscriptions }) => {
    if (subscriptions.has(symbol) && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    }
  });
}

wss.on("connection", (ws) => {
  const id = Date.now() + Math.random().toString(36).slice(2);
  clients.set(id, { ws, subscriptions: new Set() });
  logger.info(`WS connected: ${id}`);

  ws.on("message", (raw) => {
    try {
      const msg = JSON.parse(raw);
      const client = clients.get(id);
      if (!client) return;

      if (msg.type === "subscribe") {
        msg.symbols.forEach(s => client.subscriptions.add(s));
        ws.send(JSON.stringify({ type: "subscribed", symbols: msg.symbols }));
      } else if (msg.type === "unsubscribe") {
        msg.symbols.forEach(s => client.subscriptions.delete(s));
      }
    } catch (e) { logger.error("WS message error:", e.message); }
  });

  ws.on("close", () => {
    clients.delete(id);
    logger.info(`WS disconnected: ${id}`);
  });
});

// ── Price simulation for demo ────────────────────────────
const prices = {};
const SYMBOLS = [
  "BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT","ADAUSDT",
  "RELIANCE","TCS","INFY","HDFC","WIPRO",
  "EURUSD","GBPUSD","USDINR","USDJPY",
  "NIFTY50","SPX500","NASDAQ",
];
const BASE_PRICES = {
  BTCUSDT:84231.5, ETHUSDT:3891.2, SOLUSDT:189.4, BNBUSDT:612.8,
  XRPUSDT:2.34, ADAUSDT:0.891, RELIANCE:2891.5, TCS:4231.0,
  INFY:1891.3, HDFC:1678.9, WIPRO:521.3, EURUSD:1.0821,
  GBPUSD:1.2734, USDINR:83.42, USDJPY:151.82,
  NIFTY50:22891.5, SPX500:5891.2, NASDAQ:19234.5,
};
SYMBOLS.forEach(s => prices[s] = BASE_PRICES[s] || 100);

// Simulate real-time price updates
setInterval(() => {
  SYMBOLS.forEach(sym => {
    const vol = sym.includes("USD") && !sym.includes("USDT") ? 0.0003 : 0.0008;
    prices[sym] = prices[sym] * (1 + (Math.random() - 0.499) * vol);
    const tick = {
      type: "tick",
      symbol: sym,
      price: +prices[sym].toFixed(sym.includes("USD") && !sym.includes("USDT") ? 4 : 2),
      timestamp: Date.now(),
      volume: +(Math.random() * 100).toFixed(2),
    };
    broadcast(sym, tick);
    // Save to DB
    db.insertTick(sym, tick.price, tick.volume);
  });
}, 1000);

// ── REST ROUTES ──────────────────────────────────────────

// Get all symbols with current prices
app.get("/api/symbols", (req, res) => {
  const data = SYMBOLS.map(s => ({
    symbol: s,
    price: +prices[s].toFixed(4),
    change24h: +(Math.random() * 6 - 3).toFixed(2),
    volume24h: +(Math.random() * 50 + 10).toFixed(1) + "B",
    category: getCat(s),
  }));
  res.json({ success: true, data });
});

function getCat(s) {
  if (["BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT","ADAUSDT"].includes(s)) return "CRYPTO";
  if (["RELIANCE","TCS","INFY","HDFC","WIPRO"].includes(s)) return "STOCKS";
  if (["EURUSD","GBPUSD","USDINR","USDJPY"].includes(s)) return "FOREX";
  return "INDEX";
}

// Get OHLCV candles
app.get("/api/candles/:symbol", (req, res) => {
  const { symbol } = req.params;
  const { tf = "1H", limit = 200 } = req.query;
  const candles = db.getCandles(symbol, tf, parseInt(limit));
  if (candles.length < 10) {
    // Generate synthetic candles
    const base = prices[symbol] || 100;
    const generated = generateCandles(base, parseInt(limit), tf);
    // Store them
    generated.forEach(c => db.insertCandle(symbol, tf, c));
    return res.json({ success: true, data: generated });
  }
  res.json({ success: true, data: candles });
});

function generateCandles(base, n, tf) {
  const intervals = { "1m":60,"5m":300,"15m":900,"1H":3600,"4H":14400,"1D":86400,"1W":604800 };
  const sec = intervals[tf] || 3600;
  const now = Math.floor(Date.now()/1000);
  let price = base;
  const vol = tf.includes("W") ? 0.04 : tf.includes("D") ? 0.025 : 0.015;
  return Array.from({ length: n }, (_, i) => {
    const o = price;
    const h = o * (1 + Math.random() * vol);
    const l = o * (1 - Math.random() * vol);
    const c = l + Math.random() * (h - l);
    price = c;
    return {
      time: now - (n - i) * sec,
      open: +o.toFixed(4), high: +h.toFixed(4),
      low: +l.toFixed(4), close: +c.toFixed(4),
      volume: +(Math.random() * 1000 + 100).toFixed(2),
    };
  });
}

// AI Analysis endpoint
app.post("/api/ai/analyze", async (req, res) => {
  const { symbol, price, indicators, screenshot } = req.body;
  if (!symbol) return res.status(400).json({ error: "symbol required" });

  const results = await runAllAIs(symbol, price, indicators, screenshot);
  const consensus = calcConsensus(results);
  
  // Save to DB
  db.saveAnalysis(symbol, consensus);
  
  res.json({ success: true, data: { models: results, consensus } });
});

// Get analysis history
app.get("/api/ai/history/:symbol", (req, res) => {
  const history = db.getAnalysisHistory(req.params.symbol, 20);
  res.json({ success: true, data: history });
});

// Save chart drawing
app.post("/api/drawings", (req, res) => {
  const { userId = "demo", symbol, tf, drawings } = req.body;
  db.saveDrawings(userId, symbol, tf, drawings);
  res.json({ success: true });
});

// Get chart drawings
app.get("/api/drawings/:symbol", (req, res) => {
  const { tf = "1H" } = req.query;
  const drawings = db.getDrawings("demo", req.params.symbol, tf);
  res.json({ success: true, data: drawings });
});

// Alerts
app.post("/api/alerts", (req, res) => {
  const alert = db.createAlert(req.body);
  res.json({ success: true, data: alert });
});

app.get("/api/alerts", (req, res) => {
  const alerts = db.getAlerts("demo");
  res.json({ success: true, data: alerts });
});

// Watchlist
app.get("/api/watchlist", (req, res) => {
  const list = db.getWatchlist("demo");
  res.json({ success: true, data: list.length ? list : SYMBOLS.slice(0, 8) });
});

app.post("/api/watchlist", (req, res) => {
  db.updateWatchlist("demo", req.body.symbols);
  res.json({ success: true });
});

// ── AI ENGINE ────────────────────────────────────────────
const AI_MODELS = [
  { id:"claude",   name:"Claude 4.6",  co:"Anthropic", real:true  },
  { id:"gpt4o",    name:"GPT-4o",      co:"OpenAI",    real:false },
  { id:"gemini",   name:"Gemini Pro",  co:"Google",    real:false },
  { id:"grok4",    name:"Grok 4",      co:"xAI",       real:false },
  { id:"deepseek", name:"DeepSeek v3", co:"DeepSeek",  real:false },
  { id:"llama4",   name:"Llama 4",     co:"Meta",      real:false },
  { id:"mistral",  name:"Mistral",     co:"Mistral",   real:false },
  { id:"qwen",     name:"Qwen 3.5",    co:"Alibaba",   real:false },
];

async function runAllAIs(symbol, price, inds, screenshot) {
  const results = await Promise.allSettled(
    AI_MODELS.map(m => analyzeWithModel(m, symbol, price, inds, screenshot))
  );
  return results.map((r, i) => ({
    ...AI_MODELS[i],
    ...(r.status === "fulfilled" ? r.value : simulateOpinion(AI_MODELS[i], price)),
    error: r.status === "rejected",
  }));
}

async function analyzeWithModel(model, symbol, price, inds, screenshot) {
  if (!model.real) {
    await new Promise(r => setTimeout(r, Math.random() * 800 + 200));
    return simulateOpinion(model, price);
  }

  // Claude (real)
  const CLAUDE_KEY = process.env.CLAUDE_API_KEY;
  if (!CLAUDE_KEY) return simulateOpinion(model, price);

  const messages = [];
  if (screenshot) {
    messages.push({
      role: "user",
      content: [
        { type: "image", source: { type: "base64", media_type: "image/png", data: screenshot } },
        { type: "text", text: buildPrompt(symbol, price, inds) }
      ]
    });
  } else {
    messages.push({ role: "user", content: buildPrompt(symbol, price, inds) });
  }

  const resp = await axios.post(
    "https://api.anthropic.com/v1/messages",
    { model: "claude-sonnet-4-20250514", max_tokens: 500, messages },
    { headers: { "x-api-key": CLAUDE_KEY, "anthropic-version": "2023-06-01", "Content-Type": "application/json" } }
  );

  return parseAIResponse(resp.data.content?.[0]?.text || "", price);
}

function buildPrompt(symbol, price, inds) {
  const indStr = inds ? `RSI:${inds.rsi}, SMA20:${inds.sma20}, SMA50:${inds.sma50}, BB:${inds.bbU}/${inds.bbL}` : "Not available";
  return `Analyze ${symbol} at price ${price}. Indicators: ${indStr}.
Reply EXACTLY:
SIGNAL: BUY/SELL/HOLD
CONFIDENCE: 55-92
ENTRY: [price]
STOP_LOSS: [price]  
TAKE_PROFIT: [price]
REASON: [1 sentence]
DRAWINGS: [{"type":"hline","y_pct":0.3,"color":"#26a69a","label":"Support"},{"type":"hline","y_pct":0.7,"color":"#ef5350","label":"Resistance"}]`;
}

function parseAIResponse(text, price) {
  const g = (k) => text.match(new RegExp(k + ":\\s*([^\\n]+)"))?.[1]?.trim();
  let drawings = [];
  try { const m = text.match(/DRAWINGS:\s*(\[[\s\S]*?\])/); if (m) drawings = JSON.parse(m[1]); } catch {}
  return {
    sig: g("SIGNAL") || "HOLD",
    conf: parseInt(g("CONFIDENCE") || "70"),
    entry: parseFloat(g("ENTRY") || price),
    sl: parseFloat(g("STOP_LOSS") || price * 0.97),
    tp: parseFloat(g("TAKE_PROFIT") || price * 1.04),
    reason: g("REASON") || "Technical analysis suggests current levels.",
    drawings,
  };
}

function simulateOpinion(model, price) {
  const seed = model.id.split("").reduce((a, c) => a + c.charCodeAt(0), 0) + Date.now() / 60000;
  const r = Math.abs(Math.sin(seed));
  const sigs = ["BUY", "SELL", "HOLD"];
  const sig = sigs[Math.floor(r * 2.9)];
  const conf = Math.floor(55 + r * 37);
  const d = sig === "BUY" ? 1 : sig === "SELL" ? -1 : 0;
  const reasons = {
    BUY: "Bullish momentum + oversold RSI. Strong support holding. Volume confirms accumulation.",
    SELL: "Bearish divergence at resistance. Distribution pattern forming. Risk/reward favors short.",
    HOLD: "Consolidation phase. Wait for breakout above resistance for clear directional trade.",
  };
  return {
    sig, conf,
    entry: +(price * (1 + d * -0.002)).toFixed(4),
    sl: +(price * (1 + d * -0.022)).toFixed(4),
    tp: +(price * (1 + d * 0.045)).toFixed(4),
    reason: reasons[sig],
    drawings: [
      { type: "hline", y_pct: 0.25, color: "#26a69a", label: `Support ${+(price*0.978).toFixed(2)}` },
      { type: "hline", y_pct: 0.75, color: "#ef5350", label: `Resistance ${+(price*1.022).toFixed(2)}` },
    ],
  };
}

function calcConsensus(results) {
  const valid = results.filter(r => !r.error);
  const buys  = valid.filter(r => r.sig === "BUY").length;
  const sells = valid.filter(r => r.sig === "SELL").length;
  const holds = valid.length - buys - sells;
  const sig   = buys > sells && buys > holds ? "BUY" : sells > buys && sells > holds ? "SELL" : "HOLD";
  const avg   = (key) => +(valid.reduce((a, r) => a + (r[key] || 0), 0) / valid.length).toFixed(4);
  const allDrawings = valid.flatMap(r => r.drawings || []);
  return {
    sig, buys, sells, holds, total: valid.length,
    conf: Math.round(valid.reduce((a, r) => a + r.conf, 0) / valid.length),
    entry: avg("entry"), sl: avg("sl"), tp: avg("tp"),
    drawings: dedupeDrawings(allDrawings),
  };
}

function dedupeDrawings(drawings) {
  // Keep unique type+label combos
  const seen = new Set();
  return drawings.filter(d => {
    const key = `${d.type}_${d.label}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  }).slice(0, 12);
}

// Alert checker
cron.schedule("* * * * *", () => {
  const alerts = db.getActiveAlerts();
  alerts.forEach(alert => {
    const price = prices[alert.symbol];
    if (!price) return;
    const triggered = alert.direction === "above" ? price >= alert.price : price <= alert.price;
    if (triggered) {
      db.triggerAlert(alert.id);
      broadcast(alert.symbol, { type: "alert", alert, currentPrice: price });
      logger.info(`Alert triggered: ${alert.symbol} ${alert.direction} ${alert.price}`);
    }
  });
});

// ── Start ────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  logger.info(`🚀 Nexus Trading Server running on port ${PORT}`);
  logger.info(`📊 WebSocket ready | ${SYMBOLS.length} symbols streaming`);
});
