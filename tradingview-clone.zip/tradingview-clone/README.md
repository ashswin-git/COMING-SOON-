# 🚀 NEXUS TRADING — TradingView Clone

A professional TradingView clone with real-time charts, drawing tools, and multi-AI analysis.

---

## ✅ Features

### 📊 Charts
- Real-time candlestick, bar, and area charts (lightweight-charts)
- Timeframes: 1m, 5m, 15m, 1H, 4H, 1D, 1W
- Technical overlays: SMA 20/50, Bollinger Bands
- RSI panel indicator

### ✏️ Drawing Tools
- Cursor, Trendline, Horizontal Line, Vertical Line
- Rectangle, Fibonacci, Arrow, Text

### 🤖 AI Analysis (8 Models)
- Claude 4.6 (Anthropic) — REAL API
- GPT-4o, Gemini Pro, Grok 4, DeepSeek v3, Llama 4, Mistral, Qwen 3.5
- Consensus signal: BUY / SELL / HOLD
- Entry, Stop Loss, Take Profit levels
- Auto-draw on chart
- Screenshot upload for AI analysis

### 📡 Real-time
- WebSocket price streaming
- Live price ticks
- Price alerts with notifications

### 🗄️ Backend
- Node.js + Express
- SQLite (WAL mode)
- REST API + WebSocket
- Rate limiting, helmet security

---

## 🛠️ Setup

### 1. Clone & Install

```bash
# Backend
cd backend
npm install
cp .env.example .env
# Edit .env — add your CLAUDE_API_KEY

# Frontend
cd ../frontend
npm install
```

### 2. Environment Variables

Edit `backend/.env`:
```
PORT=4000
FRONTEND_URL=http://localhost:3000
CLAUDE_API_KEY=sk-ant-xxxxxxxxxxxx   ← Your Claude API key
NODE_ENV=development
```

### 3. Run

```bash
# Terminal 1 — Backend
cd backend
npm run dev

# Terminal 2 — Frontend
cd frontend
npm start
```

Open: **http://localhost:3000**

---

## 📁 Project Structure

```
nexus-trading/
├── backend/
│   ├── server.js      ← Main server (Express + WS + AI)
│   ├── db.js          ← SQLite database layer
│   ├── logger.js      ← Winston logger
│   ├── .env.example   ← Environment template
│   └── package.json
│
└── frontend/
    ├── public/
    │   └── index.html
    └── src/
        ├── App.jsx    ← Main app (chart + AI panel)
        ├── App.css    ← All styles
        └── index.js   ← Entry point
```

---

## 🔌 API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/symbols` | All symbols + prices |
| GET | `/api/candles/:symbol?tf=1H` | OHLCV candles |
| POST | `/api/ai/analyze` | Run all 8 AIs |
| GET | `/api/ai/history/:symbol` | Past AI analyses |
| POST | `/api/drawings` | Save chart drawings |
| GET | `/api/drawings/:symbol` | Load drawings |
| POST | `/api/alerts` | Create price alert |
| GET | `/api/alerts` | Get all alerts |

---

## 🌐 WebSocket

Connect to `ws://localhost:4000`

```js
// Subscribe to symbol
ws.send(JSON.stringify({ type: "subscribe", symbols: ["BTCUSDT"] }))

// Receive tick
{ type: "tick", symbol: "BTCUSDT", price: 84231.5, timestamp: 1234567890 }

// Receive alert
{ type: "alert", alert: {...}, currentPrice: 85000 }
```

---

## 📈 Supported Markets

| Category | Symbols |
|----------|---------|
| Crypto | BTC, ETH, SOL, BNB, XRP, ADA |
| Stocks NSE | RELIANCE, TCS, INFY, HDFC, WIPRO |
| Stocks NASDAQ | AAPL, NVDA |
| Forex | EUR/USD, GBP/USD, USD/INR, USD/JPY |
| Indices | NIFTY50, S&P500, NASDAQ |

---

## 🚀 Production Deploy

```bash
# Build frontend
cd frontend && npm run build

# Serve with PM2
cd backend
npm install -g pm2
pm2 start server.js --name nexus-trading
```

---

## 📝 License
MIT — Free to use and modify.
