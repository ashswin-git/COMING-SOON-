// ═══════════════════════════════════════════════════════
//  NEXUS TRADING — TradingView Clone
//  Real charts + Drawing tools + Multi-AI + WebSocket
// ═══════════════════════════════════════════════════════
import { useState, useEffect, useRef, useCallback } from "react";
import { createChart, CrosshairMode, LineStyle, PriceScaleMode } from "lightweight-charts";
import axios from "axios";
import "./App.css";

const API = process.env.REACT_APP_API || "http://localhost:4000";
const WS_URL = process.env.REACT_APP_WS || "ws://localhost:4000";

// ── AI Model config ──────────────────────────────────────
const AI_MODELS = [
  { id:"claude",   name:"Claude 4.6",  co:"Anthropic", color:"#e2714a", icon:"🔶" },
  { id:"gpt4o",    name:"GPT-4o",      co:"OpenAI",    color:"#10a37f", icon:"🟢" },
  { id:"gemini",   name:"Gemini Pro",  co:"Google",    color:"#4285f4", icon:"🔵" },
  { id:"grok4",    name:"Grok 4",      co:"xAI",       color:"#e0e0e0", icon:"⚡" },
  { id:"deepseek", name:"DeepSeek v3", co:"DeepSeek",  color:"#3b82f6", icon:"🌊" },
  { id:"llama4",   name:"Llama 4",     co:"Meta",      color:"#1877f2", icon:"🦙" },
  { id:"mistral",  name:"Mistral",     co:"Mistral",   color:"#f97316", icon:"🌪" },
  { id:"qwen",     name:"Qwen 3.5",    co:"Alibaba",   color:"#ff6900", icon:"🧿" },
];

// ── Drawing tools ────────────────────────────────────────
const DRAW_TOOLS = [
  { id:"cursor",    icon:"⊹",  label:"Cursor"     },
  { id:"trendline", icon:"╱",  label:"Trendline"  },
  { id:"hline",     icon:"━",  label:"Horiz. Line"},
  { id:"vline",     icon:"┃",  label:"Vert. Line" },
  { id:"rectangle", icon:"□",  label:"Rectangle"  },
  { id:"fibonacci", icon:"⊞",  label:"Fibonacci"  },
  { id:"arrow",     icon:"↗",  label:"Arrow"      },
  { id:"text",      icon:"T",  label:"Text"       },
];

// ── Technical Indicators ─────────────────────────────────
function calcIndicators(candles) {
  if (!candles || candles.length < 20) return null;
  const c = candles.map(x => x.close);
  const n = c.length;
  const sma = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const s20 = sma(c.slice(-20));
  const s50 = sma(c.slice(-50));
  const v   = c.slice(-20).reduce((a,b) => a + (b-s20)**2, 0) / 20;
  const std = Math.sqrt(v);
  const gains = [], losses = [];
  for (let i = 1; i < Math.min(15, n); i++) {
    const d = c[n-i] - c[n-i-1];
    d > 0 ? gains.push(d) : losses.push(Math.abs(d));
  }
  const ag = gains.reduce((a,b) => a+b, 0) / 14 || 0.001;
  const al = losses.reduce((a,b) => a+b, 0) / 14 || 0.001;
  const rsi = 100 - 100 / (1 + ag/al);
  const trend = c[n-1] > s20 && s20 > s50 ? "BULLISH" : c[n-1] < s20 && s20 < s50 ? "BEARISH" : "NEUTRAL";
  return {
    rsi: +rsi.toFixed(1), sma20: +s20.toFixed(4), sma50: +s50.toFixed(4),
    bbU: +(s20+2*std).toFixed(4), bbL: +(s20-2*std).toFixed(4),
    trend, last: c[n-1],
    high24: +Math.max(...candles.slice(-24).map(x=>x.high)).toFixed(4),
    low24:  +Math.min(...candles.slice(-24).map(x=>x.low)).toFixed(4),
  };
}

// ── Draw AI annotations on canvas ───────────────────────
function renderAnnotations(canvas, annotations, high, low) {
  if (!canvas || !annotations.length) return;
  const W = canvas.offsetWidth, H = canvas.offsetHeight;
  if (!W || !H) return;
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, W, H);
  const range = (high - low) * 1.02;
  const toY = (p) => H - ((p - low * 0.99) / range) * H;
  ctx.font = "bold 10px 'JetBrains Mono',monospace";

  annotations.forEach(a => {
    ctx.save();
    ctx.strokeStyle = a.color || "#00cfff";
    ctx.fillStyle   = a.color || "#00cfff";
    ctx.lineWidth   = a.lw || 1.5;

    if (a.type === "hline" && a.price) {
      const y = toY(a.price);
      ctx.setLineDash([8, 4]);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      if (a.label) {
        const m = ctx.measureText(a.label);
        ctx.setLineDash([]);
        ctx.fillStyle = "rgba(10,11,14,0.9)";
        ctx.fillRect(W - m.width - 20, y - 14, m.width + 14, 17);
        ctx.fillStyle = a.color || "#00cfff";
        ctx.fillText(a.label, W - m.width - 13, y - 2);
      }
    } else if (a.type === "zone" && a.price1 && a.price2) {
      ctx.fillStyle = a.color;
      ctx.fillRect(0, toY(a.price2), W, toY(a.price1) - toY(a.price2));
    } else if (a.type === "arrow" && a.price) {
      const y = toY(a.price);
      const x = a.x || 60;
      const up = a.dir === "up";
      ctx.setLineDash([]);
      ctx.beginPath();
      if (up) { ctx.moveTo(x,y+18); ctx.lineTo(x,y-8); ctx.moveTo(x-8,y+4); ctx.lineTo(x,y-14); ctx.lineTo(x+8,y+4); }
      else    { ctx.moveTo(x,y-18); ctx.lineTo(x,y+8); ctx.moveTo(x-8,y-4); ctx.lineTo(x,y+14); ctx.lineTo(x+8,y-4); }
      ctx.stroke();
      if (a.label) ctx.fillText(a.label, x + 12, up ? y - 6 : y + 22);
    }
    ctx.restore();
  });
}

// ═══════════════ MAIN APP ════════════════════════════════
export default function App() {
  // State
  const [symbols, setSymbols]     = useState([]);
  const [activeSym, setActiveSym] = useState(null);
  const [candles, setCandles]     = useState([]);
  const [indicators, setIndicators] = useState(null);
  const [tf, setTF]               = useState("1H");
  const [chartType, setChartType] = useState("candlestick");
  const [liveP, setLiveP]         = useState({});
  const [drawTool, setDrawTool]   = useState("cursor");
  const [drawings, setDrawings]   = useState([]);
  const [aiCards, setAiCards]     = useState([]);
  const [consensus, setConsensus] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [rightTab, setRightTab]   = useState("ai");
  const [alerts, setAlerts]       = useState([]);
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [alertPrice, setAlertPrice] = useState("");
  const [alertDir, setAlertDir]   = useState("above");
  const [showIndicators, setShowIndicators] = useState({ rsi: false, macd: false, bb: true, sma: true });
  const [isDark]                  = useState(true);
  const [screenshot, setScreenshot] = useState(null);

  // Refs
  const chartRef   = useRef(null);
  const tvRef      = useRef(null);
  const seriesRef  = useRef(null);
  const rsiRef     = useRef(null);
  const rsiSeries  = useRef(null);
  const canvasRef  = useRef(null);
  const wsRef      = useRef(null);
  const fileRef    = useRef(null);
  const drawStart  = useRef(null);

  // ── Load symbols ────────────────────────────────────────
  useEffect(() => {
    axios.get(`${API}/api/symbols`).then(r => {
      setSymbols(r.data.data);
      if (!activeSym) setActiveSym(r.data.data[0]);
    }).catch(() => {
      // Fallback demo symbols
      const demo = [
        {symbol:"BTCUSDT",price:84231.5,change24h:2.34,category:"CRYPTO"},
        {symbol:"ETHUSDT",price:3891.2, change24h:-1.12,category:"CRYPTO"},
        {symbol:"SOLUSDT",price:189.4,  change24h:5.67, category:"CRYPTO"},
        {symbol:"RELIANCE",price:2891.5,change24h:1.23,category:"STOCKS"},
        {symbol:"TCS",     price:4231.0,change24h:-0.45,category:"STOCKS"},
        {symbol:"EURUSD",  price:1.0821,change24h:0.12,category:"FOREX"},
        {symbol:"NIFTY50", price:22891.5,change24h:0.89,category:"INDEX"},
      ];
      setSymbols(demo);
      setActiveSym(demo[0]);
    });
  }, []);

  // ── WebSocket ───────────────────────────────────────────
  useEffect(() => {
    if (!activeSym) return;
    const ws = new WebSocket(WS_URL);
    wsRef.current = ws;
    ws.onopen = () => ws.send(JSON.stringify({ type: "subscribe", symbols: [activeSym.symbol] }));
    ws.onmessage = (e) => {
      const msg = JSON.parse(e.data);
      if (msg.type === "tick") {
        setLiveP(prev => ({ ...prev, [msg.symbol]: msg.price }));
        // Update last candle
        if (seriesRef.current && msg.symbol === activeSym.symbol) {
          const now = Math.floor(Date.now() / 1000);
          seriesRef.current.update({ time: now, open: msg.price, high: msg.price, low: msg.price, close: msg.price });
        }
      } else if (msg.type === "alert") {
        alert(`🔔 Alert: ${msg.alert.symbol} hit ${msg.currentPrice.toFixed(2)}`);
      }
    };
    ws.onerror = () => {
      // Fallback: simulate prices
      const interval = setInterval(() => {
        if (!activeSym) return;
        setLiveP(prev => {
          const n = { ...prev };
          [activeSym.symbol].forEach(s => {
            const base = prev[s] || activeSym.price;
            n[s] = base * (1 + (Math.random() - 0.499) * 0.0006);
          });
          return n;
        });
      }, 1000);
      return () => clearInterval(interval);
    };
    return () => ws.close();
  }, [activeSym?.symbol]);

  // ── Load candles ────────────────────────────────────────
  useEffect(() => {
    if (!activeSym) return;
    axios.get(`${API}/api/candles/${activeSym.symbol}?tf=${tf}&limit=300`)
      .then(r => {
        setCandles(r.data.data);
        setIndicators(calcIndicators(r.data.data));
      })
      .catch(() => {
        // Generate demo candles
        const base = activeSym.price;
        const n = 200;
        const now = Math.floor(Date.now() / 1000);
        const tfs = {"1m":60,"5m":300,"15m":900,"1H":3600,"4H":14400,"1D":86400};
        const sec = tfs[tf] || 3600;
        let price = base;
        const data = Array.from({length:n},(_,i) => {
          const o=price, h=o*(1+Math.random()*0.015), l=o*(1-Math.random()*0.015);
          const c=l+Math.random()*(h-l); price=c;
          return {time:now-(n-i)*sec,open:+o.toFixed(4),high:+h.toFixed(4),low:+l.toFixed(4),close:+c.toFixed(4),volume:+(Math.random()*1000).toFixed(2)};
        });
        setCandles(data);
        setIndicators(calcIndicators(data));
      });
  }, [activeSym?.symbol, tf]);

  // ── Init chart ──────────────────────────────────────────
  useEffect(() => {
    if (!tvRef.current || !candles.length) return;
    const el = tvRef.current;

    chartRef.current?.remove();

    const chart = createChart(el, {
      width: el.clientWidth,
      height: el.clientHeight,
      layout: { background: { color: "#0a0b0e" }, textColor: "#5c6784" },
      grid: { vertLines: { color: "#111318" }, horzLines: { color: "#111318" } },
      crosshair: { mode: CrosshairMode.Normal,
        vertLine: { color: "#2e3545", labelBackgroundColor: "#181b22" },
        horzLine: { color: "#2e3545", labelBackgroundColor: "#181b22" },
      },
      rightPriceScale: { borderColor: "#1e2229", scaleMargins: { top: 0.1, bottom: 0.1 } },
      timeScale: { borderColor: "#1e2229", timeVisible: true, secondsVisible: false },
    });
    chartRef.current = chart;

    let series;
    if (chartType === "candlestick") {
      series = chart.addCandlestickSeries({
        upColor: "#26a69a", downColor: "#ef5350",
        borderUpColor: "#26a69a", borderDownColor: "#ef5350",
        wickUpColor: "#26a69a", wickDownColor: "#ef5350",
      });
    } else if (chartType === "bar") {
      series = chart.addBarSeries({ upColor: "#26a69a", downColor: "#ef5350" });
    } else {
      series = chart.addAreaSeries({
        topColor: "rgba(38,166,154,0.25)", bottomColor: "rgba(38,166,154,0.02)",
        lineColor: "#26a69a", lineWidth: 2,
      });
    }
    series.setData(candles);
    seriesRef.current = series;

    // SMA overlays
    if (showIndicators.sma && indicators) {
      const smaData = candles.map((c,i) => {
        const sl = candles.slice(Math.max(0,i-19),i+1);
        const avg = sl.reduce((a,b)=>a+b.close,0)/sl.length;
        return { time: c.time, value: +avg.toFixed(4) };
      });
      const smaSeries = chart.addLineSeries({ color: "#2196f3", lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
      smaSeries.setData(smaData);
    }

    // BB overlay
    if (showIndicators.bb && indicators) {
      const bbU = chart.addLineSeries({ color: "rgba(156,39,176,0.4)", lineWidth: 1, lineStyle: LineStyle.Dashed, priceLineVisible: false, lastValueVisible: false });
      const bbL = chart.addLineSeries({ color: "rgba(156,39,176,0.4)", lineWidth: 1, lineStyle: LineStyle.Dashed, priceLineVisible: false, lastValueVisible: false });
      bbU.setData(candles.slice(-20).map(c => ({ time:c.time, value:indicators.bbU })));
      bbL.setData(candles.slice(-20).map(c => ({ time:c.time, value:indicators.bbL })));
    }

    chart.timeScale().fitContent();

    const ro = new ResizeObserver(() => chart.applyOptions({ width: el.clientWidth, height: el.clientHeight }));
    ro.observe(el);
    return () => { ro.disconnect(); chart.remove(); };
  }, [candles, chartType, showIndicators]);

  // ── Draw AI annotations ──────────────────────────────────
  useEffect(() => {
    if (!canvasRef.current || !consensus || !indicators) return;
    const anns = buildAnnotations(consensus, indicators);
    renderAnnotations(canvasRef.current, anns, indicators.high24, indicators.low24);
  }, [consensus, indicators, liveP[activeSym?.symbol]]);

  function buildAnnotations(cons, inds) {
    return [
      { type:"hline", price:cons.tp,    color:"#ffa726", lw:1.5, label:`TARGET  ${cons.tp}` },
      { type:"hline", price:cons.entry, color:"#26a69a", lw:2,   label:`ENTRY   ${cons.entry}` },
      { type:"hline", price:cons.sl,    color:"#ef5350", lw:1.5, label:`STOP    ${cons.sl}` },
      { type:"zone",  price1:cons.entry,price2:cons.sl,   color: cons.sig==="BUY"?"rgba(239,83,80,0.06)":"rgba(38,166,154,0.06)" },
      { type:"zone",  price1:cons.tp,   price2:cons.entry,color: cons.sig==="BUY"?"rgba(38,166,154,0.06)":"rgba(239,83,80,0.06)" },
      { type:"arrow", price:cons.entry, dir:cons.sig==="BUY"?"up":"down", x:60, color:cons.sig==="BUY"?"#26a69a":"#ef5350", label:cons.sig },
      { type:"hline", price:inds.bbU,   color:"rgba(156,39,176,0.5)", lw:1, label:`BB+ ${inds.bbU}` },
      { type:"hline", price:inds.bbL,   color:"rgba(156,39,176,0.5)", lw:1, label:`BB- ${inds.bbL}` },
    ];
  }

  // ── Run AI analysis ──────────────────────────────────────
  const analyzeAll = useCallback(async () => {
    if (!activeSym || aiLoading) return;
    setAiLoading(true);
    setAiCards(AI_MODELS.map(m => ({ ...m, loading: true })));
    setConsensus(null);

    try {
      const resp = await axios.post(`${API}/api/ai/analyze`, {
        symbol: activeSym.symbol,
        price: liveP[activeSym.symbol] || activeSym.price,
        indicators,
        screenshot: screenshot ? screenshot.split(",")[1] : null,
      });
      const { models, consensus: cons } = resp.data.data;
      setAiCards(models.map(m => ({ ...m, loading: false })));
      setConsensus(cons);
    } catch {
      // Demo fallback
      const price = liveP[activeSym.symbol] || activeSym.price;
      const cards = AI_MODELS.map(m => {
        const sigs = ["BUY","SELL","HOLD"];
        const sig = sigs[Math.floor(Math.random()*2.9)];
        const d = sig==="BUY"?1:sig==="SELL"?-1:0;
        return {
          ...m, loading:false, sig, conf:Math.floor(55+Math.random()*37),
          entry: +(price*(1+d*-0.002)).toFixed(4),
          sl:    +(price*(1+d*-0.022)).toFixed(4),
          tp:    +(price*(1+d*0.045)).toFixed(4),
          reason: sig==="BUY"?"Bullish momentum, oversold RSI, volume surge.":sig==="SELL"?"Bearish divergence at resistance, distribution.":"Consolidation — wait for breakout.",
        };
      });
      setAiCards(cards);
      const buys=cards.filter(c=>c.sig==="BUY").length, sells=cards.filter(c=>c.sig==="SELL").length;
      const holds=cards.length-buys-sells;
      const sig=buys>sells&&buys>holds?"BUY":sells>buys&&sells>holds?"SELL":"HOLD";
      setConsensus({ sig, buys, sells, holds, total:cards.length,
        conf:Math.round(cards.reduce((a,b)=>a+b.conf,0)/cards.length),
        entry:+(cards.reduce((a,b)=>a+b.entry,0)/cards.length).toFixed(4),
        sl:+(cards.reduce((a,b)=>a+b.sl,0)/cards.length).toFixed(4),
        tp:+(cards.reduce((a,b)=>a+b.tp,0)/cards.length).toFixed(4),
      });
    }
    setAiLoading(false);
    setScreenshot(null);
  }, [activeSym, aiLoading, indicators, liveP, screenshot]);

  // ── File upload ──────────────────────────────────────────
  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const r = new FileReader();
    r.onload = (ev) => { setScreenshot(ev.target.result); setRightTab("ai"); };
    r.readAsDataURL(file);
  };

  // ── Create alert ─────────────────────────────────────────
  const createAlert = async () => {
    if (!alertPrice || !activeSym) return;
    const alert = { symbol: activeSym.symbol, price: parseFloat(alertPrice), direction: alertDir, label: `${alertDir} ${alertPrice}` };
    try {
      await axios.post(`${API}/api/alerts`, alert);
    } catch {}
    setAlerts(prev => [...prev, { ...alert, id: Date.now(), active: 1 }]);
    setShowAlertModal(false);
    setAlertPrice("");
  };

  const price  = liveP[activeSym?.symbol] || activeSym?.price || 0;
  const isUp   = (activeSym?.change24h || 0) >= 0;
  const cats   = ["CRYPTO","STOCKS","FOREX","INDEX"];
  const grouped = cats.reduce((acc,cat) => { acc[cat] = symbols.filter(s=>s.category===cat); return acc; }, {});

  return (
    <div className="app">
      {/* ── TOP BAR ── */}
      <div className="topbar">
        <div className="logo">
          <div className="lm">NX</div>
          <div><div className="ln">NEXUS</div><span className="ls">TRADING</span></div>
        </div>
        <div className="nav-links">
          {["Chart","Screener","Alerts","Portfolio"].map(l=>(
            <span key={l} className={`nl ${l==="Chart"?"on":""}`}>{l}</span>
          ))}
        </div>
        <div className="topbar-right">
          {activeSym && (
            <div className="sym-display">
              <span className="sd-sym">{activeSym.symbol}</span>
              <span className="sd-price" style={{color:isUp?"#26a69a":"#ef5350"}}>
                {price.toLocaleString(undefined,{maximumFractionDigits:4})}
              </span>
              <span className={`sd-chg ${isUp?"up":"dn"}`}>{isUp?"▲":"▼"}{Math.abs(activeSym.change24h||0)}%</span>
            </div>
          )}
          <button className="icon-btn" onClick={()=>setShowAlertModal(true)}>🔔</button>
          <button className="icon-btn" onClick={()=>fileRef.current?.click()}>📸</button>
          <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={handleFile}/>
          <div className="avatar">U</div>
        </div>
      </div>

      {/* ── SYMBOL BAR ── */}
      <div className="symbar">
        {cats.map(cat=>(
          <div key={cat} className="symcat">
            <span className="sc-label">{cat}</span>
            {(grouped[cat]||[]).map(s=>{
              const p=liveP[s.symbol]||s.price, up=(s.change24h||0)>=0;
              return (
                <div key={s.symbol} className={`sc-chip ${activeSym?.symbol===s.symbol?"on":""}`}
                  onClick={()=>{setActiveSym(s);setAiCards([]);setConsensus(null);}}>
                  <span className="sc-name">{s.symbol.replace("USDT","").replace("USD","")}</span>
                  <span className="sc-p">{p.toLocaleString(undefined,{maximumFractionDigits:2})}</span>
                  <span className={`sc-c ${up?"up":"dn"}`}>{up?"▲":"▼"}{Math.abs(s.change24h||0)}%</span>
                </div>
              );
            })}
            <div className="sc-div"/>
          </div>
        ))}
      </div>

      {/* ── BODY ── */}
      <div className="body">

        {/* DRAWING TOOLBAR */}
        <div className="draw-toolbar">
          {DRAW_TOOLS.map(tool=>(
            <button key={tool.id} className={`dt-btn ${drawTool===tool.id?"on":""}`}
              onClick={()=>setDrawTool(tool.id)} title={tool.label}>
              {tool.icon}
            </button>
          ))}
          <div style={{flex:1}}/>
          <button className="dt-btn danger" onClick={()=>setDrawings([])} title="Clear drawings">⊗</button>
        </div>

        {/* CHART AREA */}
        <div className="chart-area">
          <div className="chart-toolbar">
            {/* Timeframes */}
            {[["1m","1m"],["5m","5m"],["15m","15m"],["1H","1H"],["4H","4H"],["1D","1D"],["1W","1W"]].map(([v,l])=>(
              <button key={v} className={`tb ${tf===v?"on":""}`} onClick={()=>setTF(v)}>{l}</button>
            ))}
            <div className="tb-sep"/>
            {/* Chart types */}
            {[["candlestick","📊"],["area","📈"],["bar","📉"]].map(([v,l])=>(
              <button key={v} className={`tb ${chartType===v?"on":""}`} onClick={()=>setChartType(v)} title={v}>{l}</button>
            ))}
            <div className="tb-sep"/>
            {/* Indicators */}
            {[["sma","SMA"],["bb","BB"],["rsi","RSI"],["macd","MACD"]].map(([k,l])=>(
              <button key={k} className={`tb ${showIndicators[k]?"on":""}`}
                onClick={()=>setShowIndicators(p=>({...p,[k]:!p[k]}))}>
                {l}
              </button>
            ))}
            <div style={{flex:1}}/>
            <button className="ai-analyze-btn" onClick={analyzeAll} disabled={aiLoading}>
              {aiLoading ? "⏳ Analyzing..." : "🤖 Analyze (8 AIs)"}
            </button>
            {screenshot && <span style={{fontSize:11,color:"#ffa726",marginLeft:8}}>📸 Screenshot ready</span>}
          </div>

          <div className="chart-wrap">
            <div ref={tvRef} className="tv-chart"/>
            <canvas ref={canvasRef} className="ai-overlay"/>
          </div>

          {/* Indicators sub-panel */}
          {showIndicators.rsi && indicators && (
            <div className="ind-panel">
              <div style={{fontSize:10,color:"#5c6784",marginBottom:4}}>RSI(14)</div>
              <div className="rsi-bar">
                <div className="rsi-fill" style={{
                  width:`${indicators.rsi}%`,
                  background:indicators.rsi>70?"#ef5350":indicators.rsi<30?"#26a69a":"#ffa726"
                }}/>
              </div>
              <div style={{fontFamily:"JetBrains Mono,monospace",fontSize:11,marginTop:4,
                color:indicators.rsi>70?"#ef5350":indicators.rsi<30?"#26a69a":"#ffa726"}}>
                {indicators.rsi}
              </div>
            </div>
          )}

          {/* Stats bar */}
          <div className="stats-bar">
            {indicators && [
              ["SMA20",indicators.sma20,"#2196f3"],
              ["SMA50",indicators.sma50,"#ff9800"],
              ["BB+",indicators.bbU,"#9c27b0"],
              ["BB-",indicators.bbL,"#9c27b0"],
              ["RSI",indicators.rsi,indicators.rsi>70?"#ef5350":indicators.rsi<30?"#26a69a":"#ffa726"],
              ["Trend",indicators.trend,indicators.trend==="BULLISH"?"#26a69a":indicators.trend==="BEARISH"?"#ef5350":"#ffa726"],
            ].map(([l,v,c])=>(
              <div key={l} className="sb-item">
                <span style={{color:"#3a5a7a"}}>{l} </span>
                <span style={{color:c,fontFamily:"JetBrains Mono,monospace",fontWeight:600}}>{v}</span>
              </div>
            ))}
            {consensus && (
              <div className="sb-item" style={{marginLeft:"auto"}}>
                <span style={{color:"#3a5a7a"}}>CONSENSUS </span>
                <span style={{color:consensus.sig==="BUY"?"#26a69a":consensus.sig==="SELL"?"#ef5350":"#ffa726",
                  fontFamily:"JetBrains Mono,monospace",fontWeight:700}}>
                  {consensus.sig} ({consensus.conf}%)
                </span>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT PANEL */}
        <div className="right-panel">
          <div className="rp-tabs">
            {[["ai","AI"],["ind","Indicators"],["alerts","Alerts"]].map(([k,l])=>(
              <div key={k} className={`rpt ${rightTab===k?"on":""}`} onClick={()=>setRightTab(k)}>{l}</div>
            ))}
          </div>

          <div className="rp-body">
            {/* AI Tab */}
            {rightTab==="ai" && (
              <>
                {screenshot && (
                  <div className="screenshot-preview">
                    <img src={screenshot} alt="chart" style={{width:"100%",borderRadius:6,marginBottom:8}}/>
                    <div style={{fontSize:10,color:"#ffa726",textAlign:"center"}}>
                      📸 Screenshot — click Analyze to send to AI
                    </div>
                  </div>
                )}
                {!aiCards.length && !aiLoading && (
                  <div className="ai-empty">
                    <div className="ae-icon">🤖</div>
                    <div className="ae-title">Multi-AI Analysis</div>
                    <div className="ae-desc">8 AI models analyze simultaneously and give consensus signal with Entry, SL & TP</div>
                    <button className="ae-btn" onClick={analyzeAll}>Analyze {activeSym?.symbol}</button>
                  </div>
                )}
                {consensus && (
                  <div className="consensus-card">
                    <div className="cc-label">CONSENSUS — {consensus.total} AIs</div>
                    <div className="cc-sig" style={{color:consensus.sig==="BUY"?"#26a69a":consensus.sig==="SELL"?"#ef5350":"#ffa726"}}>
                      {consensus.sig}
                    </div>
                    <div className="cc-conf">
                      <span style={{color:"#3a5a7a",fontSize:10}}>Confidence</span>
                      <div className="cc-bar"><div className="cc-fill" style={{width:`${consensus.conf}%`}}/></div>
                      <span style={{fontFamily:"JetBrains Mono,monospace",fontSize:11,color:"#2196f3"}}>{consensus.conf}%</span>
                    </div>
                    <div className="cc-vote">
                      <div className="cv-bar">
                        <div style={{height:"100%",background:"#26a69a",width:`${consensus.buys/consensus.total*100}%`}}/>
                        <div style={{height:"100%",background:"#ffa726",width:`${consensus.holds/consensus.total*100}%`}}/>
                        <div style={{height:"100%",background:"#ef5350",width:`${consensus.sells/consensus.total*100}%`}}/>
                      </div>
                      <div className="cv-nums">
                        <span style={{color:"#26a69a"}}>🟢 {consensus.buys}</span>
                        <span style={{color:"#ffa726"}}>🟡 {consensus.holds}</span>
                        <span style={{color:"#ef5350"}}>🔴 {consensus.sells}</span>
                      </div>
                    </div>
                    <div className="cc-levels">
                      {[{l:"ENTRY",v:consensus.entry,c:"#26a69a"},{l:"SL",v:consensus.sl,c:"#ef5350"},{l:"TP",v:consensus.tp,c:"#ffa726"}].map(({l,v,c})=>(
                        <div key={l} className="cl-item" style={{borderColor:`${c}30`}}>
                          <span style={{fontSize:9,color:"#3a5a7a",letterSpacing:1}}>{l}</span>
                          <strong style={{color:c,fontFamily:"JetBrains Mono,monospace",fontSize:11}}>{v?.toFixed(2)}</strong>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {aiCards.map((c,i)=>(
                  <div key={i} className="ai-card">
                    <div className="ac-head">
                      <div className="ac-model">
                        <div className="ac-icon" style={{background:`${c.color}18`,border:`1px solid ${c.color}30`}}>{c.icon}</div>
                        <div>
                          <div style={{fontSize:12,fontWeight:600}}>{c.name}</div>
                          <div style={{fontSize:9,color:"#3a5a7a"}}>{c.co}</div>
                        </div>
                      </div>
                      {c.loading
                        ? <div style={{width:48,height:20,borderRadius:4}} className="sk"/>
                        : <span className={`ac-sig ${c.sig}`}>{c.sig}</span>
                      }
                    </div>
                    {c.loading
                      ? <><div style={{height:11,marginBottom:5,borderRadius:4}} className="sk"/><div style={{height:11,width:"70%",borderRadius:4}} className="sk"/></>
                      : <>
                          <div className="ac-reason">{c.reason}</div>
                          <div className="ac-levels">
                            {[{l:"Entry",v:c.entry,cls:"e"},{l:"SL",v:c.sl,cls:"s"},{l:"TP",v:c.tp,cls:"t"}].map(({l,v,cls})=>(
                              <div key={l} className={`al-item al-${cls}`}>
                                <span>{l}</span>
                                <strong>{v?.toFixed(2)}</strong>
                              </div>
                            ))}
                          </div>
                          <div className="ac-conf">
                            <div className="acb"><div className="acbf" style={{width:`${c.conf}%`}}/></div>
                            <span>{c.conf}%</span>
                          </div>
                        </>
                    }
                  </div>
                ))}
              </>
            )}

            {/* Indicators Tab */}
            {rightTab==="ind" && indicators && (
              <>
                <div className="ind-section">
                  <div className="is-title">TECHNICAL INDICATORS</div>
                  {[
                    ["RSI (14)", indicators.rsi, indicators.rsi>70?"Overbought":indicators.rsi<30?"Oversold":"Neutral"],
                    ["SMA 20",  indicators.sma20, "Moving Average"],
                    ["SMA 50",  indicators.sma50, "Moving Average"],
                    ["BB Upper",indicators.bbU, "Bollinger Band"],
                    ["BB Lower",indicators.bbL, "Bollinger Band"],
                    ["24H High",indicators.high24, "Daily High"],
                    ["24H Low", indicators.low24,  "Daily Low"],
                    ["Trend",   indicators.trend,   "Market Direction"],
                  ].map(([l,v,s])=>(
                    <div key={l} className="ii-row">
                      <div><div className="ii-label">{l}</div><div className="ii-sub">{s}</div></div>
                      <span className="ii-val" style={{
                        color:l==="RSI (14)"?indicators.rsi>70?"#ef5350":indicators.rsi<30?"#26a69a":"#ffa726":
                          l==="Trend"?indicators.trend==="BULLISH"?"#26a69a":indicators.trend==="BEARISH"?"#ef5350":"#ffa726":"#e8eaf0"
                      }}>{v}</span>
                    </div>
                  ))}
                </div>
                <div className="ind-section" style={{marginTop:12}}>
                  <div className="is-title">OVERLAYS</div>
                  {[["sma","SMA 20/50"],["bb","Bollinger Bands"],["rsi","RSI Panel"],["macd","MACD Panel"]].map(([k,l])=>(
                    <div key={k} className="overlay-row">
                      <span>{l}</span>
                      <div className={`toggle ${showIndicators[k]?"on":""}`}
                        onClick={()=>setShowIndicators(p=>({...p,[k]:!p[k]}))}>
                        <div className="toggle-knob"/>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}

            {/* Alerts Tab */}
            {rightTab==="alerts" && (
              <>
                <button className="create-alert-btn" onClick={()=>setShowAlertModal(true)}>
                  + Create Alert
                </button>
                {alerts.length === 0 ? (
                  <div style={{textAlign:"center",color:"#3a5a7a",padding:"20px 0",fontSize:12}}>
                    No alerts set. Create one to get notified at specific prices.
                  </div>
                ) : alerts.map((a,i)=>(
                  <div key={i} className="alert-row">
                    <div>
                      <div style={{fontWeight:600,fontSize:12}}>{a.symbol}</div>
                      <div style={{fontSize:10,color:"#3a5a7a"}}>{a.direction} {a.price}</div>
                    </div>
                    <span style={{fontSize:10,color:a.triggered?"#26a69a":"#ffa726"}}>{a.triggered?"✅":"⏳"}</span>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      </div>

      {/* ALERT MODAL */}
      {showAlertModal && (
        <div className="modal-overlay" onClick={()=>setShowAlertModal(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-title">🔔 Create Price Alert</div>
            <div className="modal-sym">{activeSym?.symbol} — Current: {price.toFixed(4)}</div>
            <select className="modal-input" value={alertDir} onChange={e=>setAlertDir(e.target.value)}>
              <option value="above">Price crosses above</option>
              <option value="below">Price crosses below</option>
            </select>
            <input className="modal-input" type="number" placeholder="Alert price" value={alertPrice} onChange={e=>setAlertPrice(e.target.value)}/>
            <div className="modal-actions">
              <button className="modal-cancel" onClick={()=>setShowAlertModal(false)}>Cancel</button>
              <button className="modal-create" onClick={createAlert}>Create Alert</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
